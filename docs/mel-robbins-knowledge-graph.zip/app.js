// Knowledge Graph Visualization with D3.js
class KnowledgeGraphApp {
    constructor() {
        this.data = null;
        this.svg = null;
        this.simulation = null;
        this.nodes = [];
        this.links = [];
        this.selectedNode = null;
        this.searchTerm = '';
        this.filters = {
            nodeType: '',
            importance: ''
        };
        this.physicsEnabled = true;
        
        this.initializeApp();
    }

    async initializeApp() {
        // Load data
        await this.loadData();
        
        // Initialize D3 visualization
        this.initializeD3();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Start the simulation
        this.startSimulation();
        
        // Mark as loaded
        document.querySelector('.graph-container').classList.add('loaded');
    }

    async loadData() {
        // Data is embedded in the application
        this.data = {
            "nodes": [
                {"id": "cluster_1", "type": "Cluster", "name": "Personal Development", "size": 15, "member_count": 45, "importance": 0.9, "color": "#2196F3"},
                {"id": "cluster_2", "type": "Cluster", "name": "Mental Health", "size": 18, "member_count": 52, "importance": 0.95, "color": "#2196F3"},
                {"id": "cluster_3", "type": "Cluster", "name": "Relationships", "size": 12, "member_count": 38, "importance": 0.8, "color": "#4CAF50"},
                {"id": "cluster_4", "type": "Cluster", "name": "Career Growth", "size": 14, "member_count": 41, "importance": 0.85, "color": "#4CAF50"},
                {"id": "cluster_5", "type": "Cluster", "name": "Productivity", "size": 16, "member_count": 47, "importance": 0.88, "color": "#2196F3"},
                {"id": "episode_1", "type": "Episode", "name": "The 5 Second Rule", "size": 8, "published_date": "2023-01-15", "importance": 0.9, "color": "#FF9800"},
                {"id": "episode_2", "type": "Episode", "name": "Anxiety Management", "size": 7, "published_date": "2023-02-10", "importance": 0.85, "color": "#FF9800"},
                {"id": "episode_3", "type": "Episode", "name": "Building Confidence", "size": 6, "published_date": "2023-03-05", "importance": 0.8, "color": "#FF9800"},
                {"id": "entity_1", "type": "Entity", "name": "Mel Robbins", "size": 5, "entity_type": "Person", "importance": 1.0, "color": "#9C27B0"},
                {"id": "entity_2", "type": "Entity", "name": "Harvard University", "size": 4, "entity_type": "Organization", "importance": 0.7, "color": "#9C27B0"},
                {"id": "entity_3", "type": "Entity", "name": "Neuroscience", "size": 4, "entity_type": "Concept", "importance": 0.75, "color": "#9C27B0"},
                {"id": "insight_1", "type": "Insight", "name": "Count down from 5 to overcome hesitation", "size": 4, "insight_type": "Behavioral", "importance": 0.9, "color": "#F44336"},
                {"id": "insight_2", "type": "Insight", "name": "Anxiety is normal response to uncertainty", "size": 3, "insight_type": "Psychological", "importance": 0.8, "color": "#F44336"},
                {"id": "insight_3", "type": "Insight", "name": "Confidence comes from taking action", "size": 3, "insight_type": "Motivational", "importance": 0.85, "color": "#F44336"},
                {"id": "quote_1", "type": "Quote", "name": "Your feelings don't matter, your actions do", "size": 3, "speaker": "Mel Robbins", "importance": 0.9, "color": "#FFC107"},
                {"id": "quote_2", "type": "Quote", "name": "Confidence is a skill, not a personality trait", "size": 3, "speaker": "Mel Robbins", "importance": 0.85, "color": "#FFC107"},
                {"id": "topic_1", "type": "Topic", "name": "Motivation", "size": 6, "importance": 0.8, "color": "#795548"},
                {"id": "topic_2", "type": "Topic", "name": "Psychology", "size": 5, "importance": 0.75, "color": "#795548"},
                {"id": "topic_3", "type": "Topic", "name": "Self-Help", "size": 7, "importance": 0.85, "color": "#795548"},
                {"id": "unit_1", "type": "MeaningfulUnit", "name": "Introduction to 5-second rule concept", "size": 3, "summary": "Explains the basic premise", "importance": 0.7, "color": "#607D8B"},
                {"id": "unit_2", "type": "MeaningfulUnit", "name": "Scientific backing for the technique", "size": 3, "summary": "Research evidence", "importance": 0.75, "color": "#607D8B"}
            ],
            "links": [
                {"source": "cluster_1", "target": "episode_1", "strength": 0.9, "type": "contains"},
                {"source": "cluster_1", "target": "insight_1", "strength": 0.8, "type": "contains"},
                {"source": "cluster_1", "target": "quote_1", "strength": 0.7, "type": "contains"},
                {"source": "cluster_2", "target": "episode_2", "strength": 0.9, "type": "contains"},
                {"source": "cluster_2", "target": "insight_2", "strength": 0.8, "type": "contains"},
                {"source": "cluster_3", "target": "episode_3", "strength": 0.8, "type": "contains"},
                {"source": "cluster_3", "target": "insight_3", "strength": 0.7, "type": "contains"},
                {"source": "cluster_3", "target": "quote_2", "strength": 0.6, "type": "contains"},
                {"source": "episode_1", "target": "entity_1", "strength": 0.9, "type": "mentions"},
                {"source": "episode_1", "target": "unit_1", "strength": 0.8, "type": "contains"},
                {"source": "episode_2", "target": "entity_3", "strength": 0.7, "type": "mentions"},
                {"source": "episode_2", "target": "unit_2", "strength": 0.7, "type": "contains"},
                {"source": "insight_1", "target": "topic_1", "strength": 0.8, "type": "relates_to"},
                {"source": "insight_2", "target": "topic_2", "strength": 0.8, "type": "relates_to"},
                {"source": "insight_3", "target": "topic_3", "strength": 0.7, "type": "relates_to"},
                {"source": "cluster_1", "target": "cluster_2", "strength": 0.6, "type": "related"},
                {"source": "cluster_2", "target": "cluster_3", "strength": 0.5, "type": "related"},
                {"source": "cluster_4", "target": "cluster_5", "strength": 0.7, "type": "related"}
            ]
        };
        
        this.nodes = [...this.data.nodes];
        this.links = [...this.data.links];
    }

    initializeD3() {
        const container = document.querySelector('.graph-container');
        const width = container.clientWidth;
        const height = container.clientHeight;

        this.svg = d3.select('#graphSvg')
            .attr('width', width)
            .attr('height', height);

        // Create zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.1, 4])
            .on('zoom', (event) => {
                this.svg.select('.graph-group').attr('transform', event.transform);
            });

        this.svg.call(zoom);

        // Create main group for graph elements
        const g = this.svg.append('g').attr('class', 'graph-group');

        // Create groups for links and nodes
        g.append('g').attr('class', 'links');
        g.append('g').attr('class', 'nodes');
        g.append('g').attr('class', 'labels');

        // Store zoom behavior for later use
        this.zoom = zoom;

        // Handle window resize
        window.addEventListener('resize', () => {
            const newWidth = container.clientWidth;
            const newHeight = container.clientHeight;
            this.svg.attr('width', newWidth).attr('height', newHeight);
            this.simulation.force('center', d3.forceCenter(newWidth / 2, newHeight / 2));
        });
    }

    startSimulation() {
        const width = this.svg.attr('width');
        const height = this.svg.attr('height');

        this.simulation = d3.forceSimulation(this.nodes)
            .force('link', d3.forceLink(this.links).id(d => d.id).distance(d => {
                // Clusters should be more spread out
                if (d.source.type === 'Cluster' || d.target.type === 'Cluster') {
                    return 120;
                }
                return 80;
            }))
            .force('charge', d3.forceManyBody().strength(d => {
                // Clusters have stronger repulsion
                if (d.type === 'Cluster') {
                    return -800;
                }
                return -300;
            }))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force('collision', d3.forceCollide().radius(d => this.getNodeRadius(d) + 5));

        this.simulation.on('tick', () => {
            this.updatePositions();
        });

        this.renderGraph();
    }

    getNodeRadius(d) {
        // Clusters are larger
        if (d.type === 'Cluster') {
            return Math.max(25, d.size * 2.5);
        }
        return Math.max(8, d.size * 1.5);
    }

    renderGraph() {
        this.renderLinks();
        this.renderNodes();
        this.renderLabels();
    }

    renderLinks() {
        const linkSelection = this.svg.select('.links')
            .selectAll('.link')
            .data(this.links, d => `${d.source.id}-${d.target.id}`);

        linkSelection.enter()
            .append('line')
            .attr('class', 'link')
            .style('stroke-width', d => Math.max(1, d.strength * 3))
            .merge(linkSelection);

        linkSelection.exit().remove();
    }

    renderNodes() {
        const nodeSelection = this.svg.select('.nodes')
            .selectAll('.node')
            .data(this.nodes, d => d.id);

        const nodeEnter = nodeSelection.enter()
            .append('circle')
            .attr('class', 'node')
            .attr('r', d => this.getNodeRadius(d))
            .style('fill', d => d.color)
            .style('stroke', d => d.type === 'Cluster' ? '#ffffff' : d.color)
            .call(this.drag());

        nodeEnter
            .on('click', (event, d) => {
                this.selectNode(d);
                event.stopPropagation();
            })
            .on('mouseover', (event, d) => {
                this.showTooltip(event, d);
            })
            .on('mouseout', () => {
                this.hideTooltip();
            });

        nodeSelection.merge(nodeEnter);
        nodeSelection.exit().remove();
    }

    renderLabels() {
        const labelSelection = this.svg.select('.labels')
            .selectAll('.node-label')
            .data(this.nodes, d => d.id);

        const labelEnter = labelSelection.enter()
            .append('text')
            .attr('class', 'node-label')
            .attr('dy', '.35em')
            .style('font-size', d => {
                if (d.type === 'Cluster') return '14px';
                return d.size > 6 ? '12px' : '10px';
            })
            .style('font-weight', d => d.type === 'Cluster' ? 'bold' : 'normal')
            .text(d => {
                // Truncate long names
                const maxLength = d.type === 'Cluster' ? 18 : 12;
                return d.name.length > maxLength ? d.name.substring(0, maxLength) + '...' : d.name;
            });

        labelSelection.merge(labelEnter);
        labelSelection.exit().remove();
    }

    updatePositions() {
        this.svg.selectAll('.link')
            .attr('x1', d => d.source.x)
            .attr('y1', d => d.source.y)
            .attr('x2', d => d.target.x)
            .attr('y2', d => d.target.y);

        this.svg.selectAll('.node')
            .attr('cx', d => d.x)
            .attr('cy', d => d.y);

        this.svg.selectAll('.node-label')
            .attr('x', d => d.x)
            .attr('y', d => d.y);
    }

    drag() {
        return d3.drag()
            .on('start', (event, d) => {
                if (!event.active && this.physicsEnabled) {
                    this.simulation.alphaTarget(0.3).restart();
                }
                d.fx = d.x;
                d.fy = d.y;
            })
            .on('drag', (event, d) => {
                d.fx = event.x;
                d.fy = event.y;
            })
            .on('end', (event, d) => {
                if (!event.active && this.physicsEnabled) {
                    this.simulation.alphaTarget(0);
                }
                d.fx = null;
                d.fy = null;
            });
    }

    selectNode(node) {
        this.selectedNode = node;
        
        // Update visual selection
        this.svg.selectAll('.node')
            .classed('selected', d => d.id === node.id)
            .classed('dimmed', d => d.id !== node.id);

        this.svg.selectAll('.link')
            .classed('selected', d => d.source.id === node.id || d.target.id === node.id)
            .classed('dimmed', d => d.source.id !== node.id && d.target.id !== node.id);

        // Update details panel
        this.updateDetailsPanel(node);
    }

    updateDetailsPanel(node) {
        const detailsContainer = document.getElementById('nodeDetails');
        
        let html = `
            <div class="detail-item">
                <div class="detail-label">Name:</div>
                <div class="detail-value">${node.name}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Type:</div>
                <div class="detail-value">${node.type}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Importance:</div>
                <div class="detail-value">${(node.importance * 100).toFixed(0)}%</div>
            </div>
        `;

        // Add type-specific details
        if (node.type === 'Cluster') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Members:</div>
                    <div class="detail-value">${node.member_count}</div>
                </div>
            `;
        } else if (node.type === 'Episode') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Published:</div>
                    <div class="detail-value">${node.published_date}</div>
                </div>
            `;
        } else if (node.type === 'Entity') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Entity Type:</div>
                    <div class="detail-value">${node.entity_type || 'N/A'}</div>
                </div>
            `;
        } else if (node.type === 'Insight') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Insight Type:</div>
                    <div class="detail-value">${node.insight_type || 'N/A'}</div>
                </div>
            `;
        } else if (node.type === 'Quote') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Speaker:</div>
                    <div class="detail-value">${node.speaker || 'N/A'}</div>
                </div>
            `;
        } else if (node.type === 'MeaningfulUnit') {
            html += `
                <div class="detail-item">
                    <div class="detail-label">Summary:</div>
                    <div class="detail-value">${node.summary || 'N/A'}</div>
                </div>
            `;
        }

        // Add connections
        const connections = this.links.filter(link => 
            link.source.id === node.id || link.target.id === node.id
        );

        if (connections.length > 0) {
            html += `
                <div class="detail-connections">
                    <div class="detail-label">Connections (${connections.length}):</div>
                    ${connections.map(conn => {
                        const connectedNode = conn.source.id === node.id ? conn.target : conn.source;
                        return `
                            <div class="connection-item">
                                <span class="connection-type">${conn.type}</span>
                                <span>${connectedNode.name}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }

        detailsContainer.innerHTML = html;
    }

    showTooltip(event, node) {
        const tooltip = document.getElementById('tooltip');
        
        tooltip.innerHTML = `
            <div class="tooltip-type">${node.type}</div>
            <div class="tooltip-title">${node.name}</div>
            <div class="tooltip-content">
                Importance: ${(node.importance * 100).toFixed(0)}%
                ${node.member_count ? `<br>Members: ${node.member_count}` : ''}
                ${node.published_date ? `<br>Published: ${node.published_date}` : ''}
            </div>
        `;
        
        tooltip.style.left = (event.pageX + 10) + 'px';
        tooltip.style.top = (event.pageY - 10) + 'px';
        tooltip.classList.add('visible');
    }

    hideTooltip() {
        document.getElementById('tooltip').classList.remove('visible');
    }

    setupEventListeners() {
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.searchTerm = e.target.value.toLowerCase();
            this.applyFilters();
        });

        document.getElementById('clearSearch').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            this.searchTerm = '';
            this.applyFilters();
        });

        // Filter functionality
        document.getElementById('nodeTypeFilter').addEventListener('change', (e) => {
            this.filters.nodeType = e.target.value;
            this.applyFilters();
        });

        document.getElementById('importanceFilter').addEventListener('change', (e) => {
            this.filters.importance = e.target.value;
            this.applyFilters();
        });

        document.getElementById('resetFilters').addEventListener('click', () => {
            document.getElementById('nodeTypeFilter').value = '';
            document.getElementById('importanceFilter').value = '';
            document.getElementById('searchInput').value = '';
            this.filters = { nodeType: '', importance: '' };
            this.searchTerm = '';
            this.applyFilters();
        });

        // Graph controls
        document.getElementById('resetZoom').addEventListener('click', () => {
            this.svg.transition().duration(750).call(
                this.zoom.transform,
                d3.zoomIdentity
            );
        });

        document.getElementById('centerGraph').addEventListener('click', () => {
            this.simulation.alpha(1).restart();
        });

        document.getElementById('togglePhysics').addEventListener('click', (e) => {
            this.physicsEnabled = !this.physicsEnabled;
            const button = e.target;
            if (this.physicsEnabled) {
                this.simulation.alpha(0.3).restart();
                button.textContent = 'Pause Physics';
            } else {
                this.simulation.stop();
                button.textContent = 'Resume Physics';
            }
        });

        // Click outside to deselect
        this.svg.on('click', () => {
            this.selectedNode = null;
            this.svg.selectAll('.node').classed('selected', false).classed('dimmed', false);
            this.svg.selectAll('.link').classed('selected', false).classed('dimmed', false);
            document.getElementById('nodeDetails').innerHTML = '<p class="placeholder-text">Click on a node to see details</p>';
        });
    }

    applyFilters() {
        let visibleNodes = [];
        
        this.svg.selectAll('.node')
            .style('display', d => {
                const matches = this.matchesFilters(d);
                if (matches) {
                    visibleNodes.push(d);
                }
                return matches ? 'block' : 'none';
            })
            .classed('highlighted', d => this.matchesFilters(d) && this.searchTerm.length > 0);

        this.svg.selectAll('.node-label')
            .style('display', d => this.matchesFilters(d) ? 'block' : 'none');

        this.svg.selectAll('.link')
            .style('display', d => {
                const sourceVisible = this.matchesFilters(d.source);
                const targetVisible = this.matchesFilters(d.target);
                return sourceVisible && targetVisible ? 'block' : 'none';
            });

        // Update simulation with visible nodes
        if (visibleNodes.length !== this.nodes.length) {
            this.simulation.nodes(visibleNodes);
            this.simulation.alpha(0.3).restart();
        } else {
            this.simulation.nodes(this.nodes);
        }
    }

    matchesFilters(node) {
        // Search filter
        if (this.searchTerm && !node.name.toLowerCase().includes(this.searchTerm)) {
            return false;
        }

        // Node type filter
        if (this.filters.nodeType && node.type !== this.filters.nodeType) {
            return false;
        }

        // Importance filter
        if (this.filters.importance) {
            if (this.filters.importance === 'high' && node.importance < 0.8) {
                return false;
            }
            if (this.filters.importance === 'medium' && (node.importance < 0.6 || node.importance >= 0.8)) {
                return false;
            }
            if (this.filters.importance === 'low' && node.importance >= 0.6) {
                return false;
            }
        }

        return true;
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new KnowledgeGraphApp();
});