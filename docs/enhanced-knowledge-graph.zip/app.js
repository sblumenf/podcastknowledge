// Knowledge Graph Application
class KnowledgeGraph {
    constructor() {
        this.data = this.initializeData();
        this.nodes = [];
        this.links = [];
        this.selectedNode = null;
        this.expandedClusters = new Set();
        this.expandedUnits = new Set();
        this.expandedTopics = new Set();
        this.searchResults = [];
        this.filters = {
            clusters: true,
            units: true,
            topics: true,
            insights: true
        };
        
        this.initializeGraph();
        this.setupEventListeners();
        this.populateAnalytics();
    }

    initializeData() {
        return {
            "clusters": [
                {"id": "cluster_1", "label": "Personal Growth", "memberCount": 45, "centroid": [0.2, 0.3], "status": "active"},
                {"id": "cluster_2", "label": "Confidence Building", "memberCount": 38, "centroid": [0.8, 0.1], "status": "active"},
                {"id": "cluster_3", "label": "Career Success", "memberCount": 52, "centroid": [0.1, 0.9], "status": "active"},
                {"id": "cluster_4", "label": "Relationships", "memberCount": 29, "centroid": [0.7, 0.8], "status": "active"},
                {"id": "cluster_5", "label": "Mental Health", "memberCount": 61, "centroid": [0.5, 0.2], "status": "active"},
                {"id": "cluster_6", "label": "Productivity", "memberCount": 33, "centroid": [0.3, 0.7], "status": "active"},
                {"id": "cluster_7", "label": "Life Transitions", "memberCount": 41, "centroid": [0.9, 0.5], "status": "active"},
                {"id": "cluster_8", "label": "Self-Discipline", "memberCount": 27, "centroid": [0.4, 0.1], "status": "active"},
                {"id": "cluster_9", "label": "Fear & Anxiety", "memberCount": 49, "centroid": [0.6, 0.9], "status": "active"},
                {"id": "cluster_10", "label": "Communication", "memberCount": 35, "centroid": [0.2, 0.6], "status": "active"}
            ],
            "meaningfulUnits": [
                {"id": "unit_1", "text": "The 5-second rule for overcoming hesitation", "clusterId": "cluster_1", "summary": "Simple technique to take action before overthinking", "embedding": [0.21, 0.32], "speakerDistribution": {"mel": 0.8, "guest": 0.2}},
                {"id": "unit_2", "text": "Building unshakeable self-confidence through action", "clusterId": "cluster_2", "summary": "Confidence comes from taking action despite fear", "embedding": [0.79, 0.11], "speakerDistribution": {"mel": 0.6, "guest": 0.4}},
                {"id": "unit_3", "text": "Navigating career pivots in your 30s and 40s", "clusterId": "cluster_3", "summary": "Strategic approach to major career changes", "embedding": [0.12, 0.88], "speakerDistribution": {"mel": 0.4, "guest": 0.6}},
                {"id": "unit_4", "text": "Setting boundaries in toxic relationships", "clusterId": "cluster_4", "summary": "Practical strategies for relationship boundaries", "embedding": [0.71, 0.79], "speakerDistribution": {"mel": 0.7, "guest": 0.3}},
                {"id": "unit_5", "text": "Managing anxiety with mindfulness techniques", "clusterId": "cluster_5", "summary": "Evidence-based approaches to anxiety management", "embedding": [0.52, 0.19], "speakerDistribution": {"mel": 0.5, "guest": 0.5}},
                {"id": "unit_6", "text": "Time management strategies for busy professionals", "clusterId": "cluster_6", "summary": "Effective techniques for maximizing productivity", "embedding": [0.31, 0.69], "speakerDistribution": {"mel": 0.6, "guest": 0.4}},
                {"id": "unit_7", "text": "Navigating major life changes with grace", "clusterId": "cluster_7", "summary": "Embracing transitions as opportunities for growth", "embedding": [0.89, 0.51], "speakerDistribution": {"mel": 0.7, "guest": 0.3}},
                {"id": "unit_8", "text": "Building habits that stick long-term", "clusterId": "cluster_8", "summary": "Science-based approach to habit formation", "embedding": [0.41, 0.09], "speakerDistribution": {"mel": 0.8, "guest": 0.2}},
                {"id": "unit_9", "text": "Overcoming fear of failure and rejection", "clusterId": "cluster_9", "summary": "Reframing fear as a catalyst for growth", "embedding": [0.61, 0.89], "speakerDistribution": {"mel": 0.5, "guest": 0.5}},
                {"id": "unit_10", "text": "Effective communication in difficult conversations", "clusterId": "cluster_10", "summary": "Tools for navigating challenging dialogues", "embedding": [0.19, 0.61], "speakerDistribution": {"mel": 0.4, "guest": 0.6}}
            ],
            "topics": [
                {"id": "topic_1", "name": "5-Second Rule", "meaningfulUnitIds": ["unit_1"], "importance": 0.9},
                {"id": "topic_2", "name": "Action-Based Confidence", "meaningfulUnitIds": ["unit_2"], "importance": 0.8},
                {"id": "topic_3", "name": "Career Transitions", "meaningfulUnitIds": ["unit_3"], "importance": 0.7},
                {"id": "topic_4", "name": "Boundary Setting", "meaningfulUnitIds": ["unit_4"], "importance": 0.6},
                {"id": "topic_5", "name": "Mindfulness Practice", "meaningfulUnitIds": ["unit_5"], "importance": 0.8},
                {"id": "topic_6", "name": "Time Management", "meaningfulUnitIds": ["unit_6"], "importance": 0.7},
                {"id": "topic_7", "name": "Life Transitions", "meaningfulUnitIds": ["unit_7"], "importance": 0.6},
                {"id": "topic_8", "name": "Habit Formation", "meaningfulUnitIds": ["unit_8"], "importance": 0.8},
                {"id": "topic_9", "name": "Fear Management", "meaningfulUnitIds": ["unit_9"], "importance": 0.7},
                {"id": "topic_10", "name": "Communication Skills", "meaningfulUnitIds": ["unit_10"], "importance": 0.6}
            ],
            "insights": [
                {"id": "insight_1", "text": "Small actions create momentum for bigger changes", "topicIds": ["topic_1"], "importance": 0.9, "insightType": "actionable", "supportingEvidence": "Multiple studies on behavioral psychology"},
                {"id": "insight_2", "text": "Confidence is a skill that can be developed through practice", "topicIds": ["topic_2"], "importance": 0.8, "insightType": "mindset", "supportingEvidence": "Research on self-efficacy theory"},
                {"id": "insight_3", "text": "Career pivots require strategic planning and emotional resilience", "topicIds": ["topic_3"], "importance": 0.7, "insightType": "strategic", "supportingEvidence": "Career transition studies"},
                {"id": "insight_4", "text": "Boundaries are essential for healthy relationships", "topicIds": ["topic_4"], "importance": 0.8, "insightType": "relational", "supportingEvidence": "Psychology research on relationship dynamics"},
                {"id": "insight_5", "text": "Mindfulness reduces anxiety and improves focus", "topicIds": ["topic_5"], "importance": 0.9, "insightType": "wellness", "supportingEvidence": "Neuroscience studies on meditation"}
            ],
            "quotes": [
                {"id": "quote_1", "text": "You are one decision away from a completely different life", "speaker": "mel", "importance": 0.95, "context": "Discussion about taking decisive action", "topicIds": ["topic_1"]},
                {"id": "quote_2", "text": "Confidence is not about feeling ready; it's about acting despite not feeling ready", "speaker": "mel", "importance": 0.9, "context": "Building self-confidence episode", "topicIds": ["topic_2"]},
                {"id": "quote_3", "text": "Your comfort zone is not your friend when it comes to your dreams", "speaker": "guest", "importance": 0.8, "context": "Career change discussion", "topicIds": ["topic_3"]},
                {"id": "quote_4", "text": "You teach people how to treat you by what you allow", "speaker": "mel", "importance": 0.85, "context": "Boundary setting episode", "topicIds": ["topic_4"]},
                {"id": "quote_5", "text": "The present moment is the only time over which we have dominion", "speaker": "guest", "importance": 0.8, "context": "Mindfulness discussion", "topicIds": ["topic_5"]}
            ],
            "entities": [
                {"id": "entity_1", "name": "Mel Robbins", "entityType": "person", "confidence": 0.99, "startTime": "00:00", "endTime": "45:30"},
                {"id": "entity_2", "name": "Harvard Business School", "entityType": "organization", "confidence": 0.85, "startTime": "12:45", "endTime": "14:20"},
                {"id": "entity_3", "name": "Cognitive Behavioral Therapy", "entityType": "concept", "confidence": 0.92, "startTime": "28:10", "endTime": "31:45"}
            ],
            "analytics": {
                "totalNodes": 5000,
                "totalConnections": 12000,
                "networkDensity": 0.23,
                "averageClusteringCoefficient": 0.45,
                "largestCluster": "cluster_5",
                "mostInfluentialNode": "cluster_1",
                "structuralGaps": [
                    {"cluster1": "cluster_1", "cluster2": "cluster_4", "gapScore": 0.8, "bridgePotential": "high"},
                    {"cluster1": "cluster_3", "cluster2": "cluster_5", "gapScore": 0.7, "bridgePotential": "medium"}
                ]
            }
        };
    }

    initializeGraph() {
        this.svg = d3.select("#graph-svg");
        this.width = window.innerWidth - 600;
        this.height = window.innerHeight - 100;
        
        this.svg.attr("width", this.width).attr("height", this.height);
        
        this.container = this.svg.append("g");
        
        // Initialize zoom behavior
        this.zoom = d3.zoom()
            .scaleExtent([0.1, 4])
            .on("zoom", (event) => {
                this.container.attr("transform", event.transform);
            });
        
        this.svg.call(this.zoom);
        
        // Initialize force simulation
        this.simulation = d3.forceSimulation()
            .force("link", d3.forceLink().id(d => d.id).distance(d => this.getLinkDistance(d)))
            .force("charge", d3.forceManyBody().strength(d => this.getNodeCharge(d)))
            .force("center", d3.forceCenter(this.width / 2, this.height / 2))
            .force("collision", d3.forceCollide().radius(d => this.getNodeRadius(d) + 2));
        
        this.buildInitialGraph();
    }

    buildInitialGraph() {
        // Start with all 10 clusters
        this.nodes = this.data.clusters.map(cluster => ({
            ...cluster,
            type: 'cluster',
            radius: 18,
            x: cluster.centroid[0] * this.width,
            y: cluster.centroid[1] * this.height
        }));
        
        // Add cluster-to-cluster relationships
        this.links = [
            {source: "cluster_1", target: "cluster_2", weight: 0.6},
            {source: "cluster_2", target: "cluster_3", weight: 0.4},
            {source: "cluster_3", target: "cluster_4", weight: 0.3},
            {source: "cluster_4", target: "cluster_5", weight: 0.5},
            {source: "cluster_5", target: "cluster_6", weight: 0.4},
            {source: "cluster_6", target: "cluster_7", weight: 0.3},
            {source: "cluster_7", target: "cluster_8", weight: 0.4},
            {source: "cluster_8", target: "cluster_9", weight: 0.5},
            {source: "cluster_9", target: "cluster_10", weight: 0.3},
            {source: "cluster_1", target: "cluster_5", weight: 0.7},
            {source: "cluster_2", target: "cluster_6", weight: 0.3},
            {source: "cluster_3", target: "cluster_7", weight: 0.4}
        ];
        
        this.updateGraph();
    }

    expandCluster(clusterId) {
        if (this.expandedClusters.has(clusterId)) return;
        
        this.expandedClusters.add(clusterId);
        
        // Add meaningful units for this cluster
        const units = this.data.meaningfulUnits.filter(unit => unit.clusterId === clusterId);
        const cluster = this.nodes.find(n => n.id === clusterId);
        
        if (!cluster) return;
        
        units.forEach((unit, index) => {
            const angle = (index / units.length) * 2 * Math.PI;
            const distance = 80;
            this.nodes.push({
                ...unit,
                type: 'meaningful-unit',
                radius: 10,
                x: cluster.x + Math.cos(angle) * distance,
                y: cluster.y + Math.sin(angle) * distance
            });
            
            // Add link from cluster to unit
            this.links.push({
                source: clusterId,
                target: unit.id,
                weight: 1.0,
                type: 'contains'
            });
        });
        
        this.updateGraph();
        this.updateBreadcrumb([`Cluster: ${cluster.label}`]);
    }

    expandMeaningfulUnit(unitId) {
        if (this.expandedUnits.has(unitId)) return;
        
        this.expandedUnits.add(unitId);
        
        // Add topics for this unit
        const topics = this.data.topics.filter(topic => topic.meaningfulUnitIds.includes(unitId));
        const unit = this.nodes.find(n => n.id === unitId);
        
        if (!unit) return;
        
        topics.forEach((topic, index) => {
            const angle = (index / topics.length) * 2 * Math.PI;
            const distance = 50;
            this.nodes.push({
                ...topic,
                type: 'topic',
                radius: 8,
                x: unit.x + Math.cos(angle) * distance,
                y: unit.y + Math.sin(angle) * distance
            });
            
            // Add link from unit to topic
            this.links.push({
                source: unitId,
                target: topic.id,
                weight: 0.8,
                type: 'discusses'
            });
        });
        
        this.updateGraph();
    }

    expandTopic(topicId) {
        if (this.expandedTopics.has(topicId)) return;
        
        this.expandedTopics.add(topicId);
        
        // Add insights, quotes, and entities for this topic
        const insights = this.data.insights.filter(insight => insight.topicIds.includes(topicId));
        const quotes = this.data.quotes.filter(quote => quote.topicIds.includes(topicId));
        const topic = this.nodes.find(n => n.id === topicId);
        
        if (!topic) return;
        
        const allItems = [...insights, ...quotes];
        
        allItems.forEach((item, index) => {
            const angle = (index / allItems.length) * 2 * Math.PI;
            const distance = 40;
            const type = item.insightType ? 'insight' : 'quote';
            
            this.nodes.push({
                ...item,
                type: type,
                radius: 5,
                x: topic.x + Math.cos(angle) * distance,
                y: topic.y + Math.sin(angle) * distance
            });
            
            // Add link from topic to item
            this.links.push({
                source: topicId,
                target: item.id,
                weight: item.importance || 0.5,
                type: 'contains'
            });
        });
        
        this.updateGraph();
    }

    updateGraph() {
        // Update links first
        const linkSelection = this.container.selectAll(".edge")
            .data(this.links, d => `${d.source.id || d.source}-${d.target.id || d.target}`);
        
        linkSelection.exit().remove();
        
        const linkEnter = linkSelection.enter()
            .append("line")
            .attr("class", "edge")
            .style("stroke", "#333")
            .style("stroke-width", d => Math.sqrt(d.weight) + 1);
        
        const linkUpdate = linkEnter.merge(linkSelection);
        
        // Update nodes
        const nodeSelection = this.container.selectAll(".node")
            .data(this.nodes, d => d.id);
        
        nodeSelection.exit().remove();
        
        const nodeEnter = nodeSelection.enter()
            .append("circle")
            .attr("class", d => `node ${d.type}`)
            .attr("r", d => d.radius)
            .style("fill", d => this.getNodeColor(d))
            .style("stroke", "#333")
            .style("stroke-width", 1)
            .style("cursor", "pointer")
            .call(this.drag())
            .on("click", (event, d) => this.handleNodeClick(event, d))
            .on("dblclick", (event, d) => this.handleNodeDoubleClick(event, d))
            .on("mouseover", (event, d) => this.showTooltip(event, d))
            .on("mouseout", () => this.hideTooltip());
        
        const nodeUpdate = nodeEnter.merge(nodeSelection);
        
        // Update simulation
        this.simulation.nodes(this.nodes);
        this.simulation.force("link").links(this.links);
        this.simulation.alpha(0.3).restart();
        
        this.simulation.on("tick", () => {
            linkUpdate
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
            
            nodeUpdate
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);
        });
    }

    handleNodeClick(event, d) {
        event.stopPropagation();
        
        // Update selection
        this.container.selectAll(".node").classed("selected", false);
        d3.select(event.currentTarget).classed("selected", true);
        
        this.selectedNode = d;
        this.updateSelectionDetails(d);
    }

    handleNodeDoubleClick(event, d) {
        event.stopPropagation();
        console.log('Double clicked:', d.type, d.id);
        
        if (d.type === 'cluster') {
            this.expandCluster(d.id);
        } else if (d.type === 'meaningful-unit') {
            this.expandMeaningfulUnit(d.id);
        } else if (d.type === 'topic') {
            this.expandTopic(d.id);
        }
    }

    getNodeColor(d) {
        const colors = {
            'cluster': '#2196F3',
            'meaningful-unit': '#4CAF50',
            'topic': '#FF9800',
            'insight': '#f44336',
            'quote': '#FFC107',
            'entity': '#9C27B0'
        };
        return colors[d.type] || '#cccccc';
    }

    getNodeRadius(d) {
        return d.radius || 5;
    }

    getNodeCharge(d) {
        const charges = {
            'cluster': -400,
            'meaningful-unit': -200,
            'topic': -100,
            'insight': -50,
            'quote': -50,
            'entity': -50
        };
        return charges[d.type] || -50;
    }

    getLinkDistance(d) {
        const distances = {
            'contains': 60,
            'discusses': 50,
            'related': 100
        };
        return distances[d.type] || 80;
    }

    drag() {
        return d3.drag()
            .on("start", (event, d) => {
                if (!event.active) this.simulation.alphaTarget(0.3).restart();
                d.fx = d.x;
                d.fy = d.y;
            })
            .on("drag", (event, d) => {
                d.fx = event.x;
                d.fy = event.y;
            })
            .on("end", (event, d) => {
                if (!event.active) this.simulation.alphaTarget(0);
                d.fx = null;
                d.fy = null;
            });
    }

    showTooltip(event, d) {
        const tooltip = d3.select("#tooltip");
        const content = this.getTooltipContent(d);
        
        tooltip.html(content)
            .style("left", (event.pageX + 10) + "px")
            .style("top", (event.pageY - 10) + "px")
            .classed("visible", true);
    }

    hideTooltip() {
        d3.select("#tooltip").classed("visible", false);
    }

    getTooltipContent(d) {
        switch (d.type) {
            case 'cluster':
                return `<strong>${d.label}</strong><br/>Members: ${d.memberCount}<br/>Type: Cluster<br/>Double-click to expand`;
            case 'meaningful-unit':
                return `<strong>Meaningful Unit</strong><br/>${d.text}<br/>Summary: ${d.summary}<br/>Double-click to expand`;
            case 'topic':
                return `<strong>${d.name}</strong><br/>Importance: ${d.importance}<br/>Type: Topic<br/>Double-click to expand`;
            case 'insight':
                return `<strong>Insight</strong><br/>${d.text}<br/>Type: ${d.insightType}`;
            case 'quote':
                return `<strong>Quote</strong><br/>"${d.text}"<br/>Speaker: ${d.speaker}`;
            case 'entity':
                return `<strong>${d.name}</strong><br/>Type: ${d.entityType}<br/>Confidence: ${d.confidence}`;
            default:
                return `<strong>${d.label || d.name || d.text}</strong>`;
        }
    }

    updateSelectionDetails(d) {
        const content = document.getElementById('selection-content');
        content.innerHTML = this.getSelectionDetailsHTML(d);
    }

    getSelectionDetailsHTML(d) {
        switch (d.type) {
            case 'cluster':
                return `
                    <div class="selection-item">
                        <h4>${d.label}</h4>
                        <p><strong>Type:</strong> Cluster</p>
                        <p><strong>Members:</strong> ${d.memberCount}</p>
                        <p><strong>Status:</strong> ${d.status}</p>
                        <p><strong>ID:</strong> ${d.id}</p>
                        <p><em>Double-click to expand and see meaningful units</em></p>
                    </div>
                `;
            case 'meaningful-unit':
                return `
                    <div class="selection-item">
                        <h4>Meaningful Unit</h4>
                        <p><strong>Text:</strong> ${d.text}</p>
                        <p><strong>Summary:</strong> ${d.summary}</p>
                        <p><strong>Cluster:</strong> ${d.clusterId}</p>
                        <p><strong>Speaker Distribution:</strong> Mel: ${Math.round(d.speakerDistribution.mel * 100)}%, Guest: ${Math.round(d.speakerDistribution.guest * 100)}%</p>
                        <p><em>Double-click to expand and see topics</em></p>
                    </div>
                `;
            case 'topic':
                return `
                    <div class="selection-item">
                        <h4>${d.name}</h4>
                        <p><strong>Type:</strong> Topic</p>
                        <p><strong>Importance:</strong> ${d.importance}</p>
                        <p><strong>Connected Units:</strong> ${d.meaningfulUnitIds.length}</p>
                        <p><em>Double-click to expand and see insights & quotes</em></p>
                    </div>
                `;
            case 'insight':
                return `
                    <div class="selection-item">
                        <h4>Insight</h4>
                        <p><strong>Text:</strong> ${d.text}</p>
                        <p><strong>Type:</strong> ${d.insightType}</p>
                        <p><strong>Importance:</strong> ${d.importance}</p>
                        <p><strong>Evidence:</strong> ${d.supportingEvidence}</p>
                    </div>
                `;
            case 'quote':
                return `
                    <div class="selection-item">
                        <h4>Quote</h4>
                        <p><strong>Text:</strong> "${d.text}"</p>
                        <p><strong>Speaker:</strong> ${d.speaker}</p>
                        <p><strong>Importance:</strong> ${d.importance}</p>
                        <p><strong>Context:</strong> ${d.context}</p>
                    </div>
                `;
            default:
                return `<p class="selection-placeholder">Click on a node to view details</p>`;
        }
    }

    updateBreadcrumb(path) {
        const breadcrumb = document.getElementById('breadcrumb');
        breadcrumb.textContent = path.join(' > ');
    }

    setupEventListeners() {
        // Sidebar toggle
        document.getElementById('sidebar-toggle').addEventListener('click', () => {
            document.getElementById('left-sidebar').classList.toggle('collapsed');
        });

        // Right panel toggle
        document.getElementById('right-panel-toggle').addEventListener('click', () => {
            document.getElementById('right-panel').classList.toggle('collapsed');
        });

        // Tab switching
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const tabName = e.target.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Graph controls
        document.getElementById('reset-zoom').addEventListener('click', () => {
            this.svg.transition().duration(750).call(
                this.zoom.transform,
                d3.zoomIdentity
            );
        });

        document.getElementById('center-graph').addEventListener('click', () => {
            this.svg.transition().duration(750).call(
                this.zoom.transform,
                d3.zoomIdentity.translate(this.width / 2, this.height / 2).scale(1)
            );
        });

        document.getElementById('expand-all').addEventListener('click', () => {
            this.data.clusters.forEach(cluster => {
                this.expandCluster(cluster.id);
            });
        });

        document.getElementById('collapse-all').addEventListener('click', () => {
            this.collapseAll();
        });

        // Zoom controls
        document.getElementById('zoom-in').addEventListener('click', () => {
            this.svg.transition().duration(300).call(
                this.zoom.scaleBy, 1.5
            );
        });

        document.getElementById('zoom-out').addEventListener('click', () => {
            this.svg.transition().duration(300).call(
                this.zoom.scaleBy, 1 / 1.5
            );
        });

        // Search
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.performSearch(e.target.value);
        });

        // AI insights
        document.getElementById('generate-insights').addEventListener('click', () => {
            this.generateInsights();
        });

        // Export functions
        document.getElementById('export-json').addEventListener('click', () => {
            this.exportJSON();
        });

        document.getElementById('export-csv').addEventListener('click', () => {
            this.exportCSV();
        });

        document.getElementById('export-svg').addEventListener('click', () => {
            this.exportSVG();
        });

        // Window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    switchTab(tabName) {
        // Remove active class from all tabs and contents
        document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

        // Add active class to selected tab and content
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(tabName).classList.add('active');
    }

    collapseAll() {
        this.expandedClusters.clear();
        this.expandedUnits.clear();
        this.expandedTopics.clear();
        this.buildInitialGraph();
        this.updateBreadcrumb([]);
    }

    performSearch(query) {
        if (!query.trim()) {
            this.clearSearch();
            return;
        }

        // Search through all data types
        const results = [];
        
        // Search clusters
        this.data.clusters.forEach(cluster => {
            if (cluster.label.toLowerCase().includes(query.toLowerCase())) {
                results.push({...cluster, type: 'cluster'});
            }
        });

        // Search meaningful units
        this.data.meaningfulUnits.forEach(unit => {
            if (unit.text.toLowerCase().includes(query.toLowerCase()) || 
                unit.summary.toLowerCase().includes(query.toLowerCase())) {
                results.push({...unit, type: 'meaningful-unit'});
            }
        });

        // Search topics
        this.data.topics.forEach(topic => {
            if (topic.name.toLowerCase().includes(query.toLowerCase())) {
                results.push({...topic, type: 'topic'});
            }
        });

        // Highlight results
        this.highlightSearchResults(results);
    }

    highlightSearchResults(results) {
        this.container.selectAll(".node").style("opacity", 0.3);
        
        results.forEach(result => {
            const node = this.nodes.find(n => n.id === result.id);
            if (node) {
                this.container.selectAll(".node").filter(d => d.id === result.id).style("opacity", 1);
            }
        });
    }

    clearSearch() {
        this.container.selectAll(".node").style("opacity", 1);
    }

    generateInsights() {
        const insightsContent = document.getElementById('ai-insights-content');
        
        if (this.selectedNode && this.selectedNode.type === 'cluster') {
            const cluster = this.selectedNode;
            const insights = [
                `What specific actions can individuals take to improve their ${cluster.label.toLowerCase()}?`,
                `How does ${cluster.label.toLowerCase()} relate to other aspects of personal development?`,
                `What are the common obstacles people face when working on ${cluster.label.toLowerCase()}?`,
                `How can technology or tools support ${cluster.label.toLowerCase()} improvement?`
            ];
            
            insightsContent.innerHTML = `
                <div class="ai-insights">
                    <h4>AI-Generated Questions for "${cluster.label}"</h4>
                    <ul>
                        ${insights.map(insight => `<li>${insight}</li>`).join('')}
                    </ul>
                </div>
            `;
        } else {
            insightsContent.innerHTML = `
                <div class="ai-insights">
                    <h4>Structural Gap Analysis</h4>
                    <p>Based on the current network structure, consider exploring:</p>
                    <ul>
                        <li>Connection between Personal Growth and Relationships clusters</li>
                        <li>Integration of Mental Health practices with Productivity techniques</li>
                        <li>Bridging Fear & Anxiety management with Confidence Building</li>
                        <li>Linking Self-Discipline strategies with Life Transitions</li>
                    </ul>
                </div>
            `;
        }
    }

    exportJSON() {
        const exportData = {
            nodes: this.nodes,
            links: this.links,
            expanded: {
                clusters: Array.from(this.expandedClusters),
                units: Array.from(this.expandedUnits),
                topics: Array.from(this.expandedTopics)
            }
        };
        
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'knowledge-graph.json';
        a.click();
        URL.revokeObjectURL(url);
    }

    exportCSV() {
        const csvData = this.nodes.map(node => ({
            id: node.id,
            label: node.label || node.name || node.text,
            type: node.type,
            importance: node.importance || node.memberCount || 'N/A'
        }));
        
        const csv = [
            ['ID', 'Label', 'Type', 'Importance'],
            ...csvData.map(row => [row.id, row.label, row.type, row.importance])
        ].map(row => row.join(',')).join('\n');
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'knowledge-graph.csv';
        a.click();
        URL.revokeObjectURL(url);
    }

    exportSVG() {
        const svgData = this.svg.node().outerHTML;
        const blob = new Blob([svgData], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'knowledge-graph.svg';
        a.click();
        URL.revokeObjectURL(url);
    }

    populateAnalytics() {
        this.populateClusterList();
        this.populateGapAnalysis();
        this.populateRelations();
        this.populateStatistics();
    }

    populateClusterList() {
        const clusterList = document.getElementById('cluster-list');
        clusterList.innerHTML = this.data.clusters
            .sort((a, b) => b.memberCount - a.memberCount)
            .map(cluster => `
                <div class="cluster-item" data-cluster-id="${cluster.id}">
                    <h4>${cluster.label}</h4>
                    <p><span class="member-count">${cluster.memberCount}</span> members</p>
                </div>
            `).join('');
        
        // Add click handlers
        clusterList.querySelectorAll('.cluster-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const clusterId = e.currentTarget.getAttribute('data-cluster-id');
                this.focusOnCluster(clusterId);
            });
        });
    }

    populateGapAnalysis() {
        const gapList = document.getElementById('gap-list');
        gapList.innerHTML = this.data.analytics.structuralGaps.map(gap => `
            <div class="gap-item">
                <h4>Gap: ${this.data.clusters.find(c => c.id === gap.cluster1).label} ↔ ${this.data.clusters.find(c => c.id === gap.cluster2).label}</h4>
                <p>Gap Score: <span class="gap-score">${gap.gapScore}</span></p>
                <p>Bridge Potential: ${gap.bridgePotential}</p>
            </div>
        `).join('');
    }

    populateRelations() {
        const relationsList = document.getElementById('relations-list');
        relationsList.innerHTML = `
            <div class="relation-item">
                <h4>Strongest Connection</h4>
                <p>Personal Growth ↔ Mental Health</p>
                <p>Weight: 0.7</p>
            </div>
            <div class="relation-item">
                <h4>Emerging Connection</h4>
                <p>Confidence Building ↔ Career Success</p>
                <p>Weight: 0.4</p>
            </div>
            <div class="relation-item">
                <h4>Weak Connection</h4>
                <p>Self-Discipline ↔ Communication</p>
                <p>Weight: 0.3</p>
            </div>
        `;
    }

    populateStatistics() {
        const statsContent = document.getElementById('stats-content');
        const stats = this.data.analytics;
        
        statsContent.innerHTML = `
            <div class="stat-item">
                <span class="stat-label">Total Clusters</span>
                <span class="stat-value">${this.data.clusters.length}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Meaningful Units</span>
                <span class="stat-value">${this.data.meaningfulUnits.length}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Topics</span>
                <span class="stat-value">${this.data.topics.length}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Network Density</span>
                <span class="stat-value">${stats.networkDensity}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Clustering Coefficient</span>
                <span class="stat-value">${stats.averageClusteringCoefficient}</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">Largest Cluster</span>
                <span class="stat-value">${this.data.clusters.find(c => c.id === stats.largestCluster).label}</span>
            </div>
        `;
    }

    focusOnCluster(clusterId) {
        const cluster = this.nodes.find(n => n.id === clusterId);
        if (cluster) {
            this.svg.transition().duration(750).call(
                this.zoom.transform,
                d3.zoomIdentity.translate(this.width / 2 - cluster.x, this.height / 2 - cluster.y).scale(2)
            );
            
            // Select the cluster
            this.container.selectAll(".node").classed("selected", false);
            this.container.selectAll(".node").filter(d => d.id === clusterId).classed("selected", true);
            this.selectedNode = cluster;
            this.updateSelectionDetails(cluster);
        }
    }

    handleResize() {
        this.width = window.innerWidth - 600;
        this.height = window.innerHeight - 100;
        
        this.svg.attr("width", this.width).attr("height", this.height);
        this.simulation.force("center", d3.forceCenter(this.width / 2, this.height / 2));
        this.simulation.restart();
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    const app = new KnowledgeGraph();
    
    // Tutorial functionality
    document.getElementById('tutorial-btn').addEventListener('click', () => {
        alert('Welcome to the Knowledge Graph Explorer!\n\n' +
              '1. Click on clusters to select them\n' +
              '2. Double-click clusters to expand and see meaningful units\n' +
              '3. Double-click meaningful units to see topics\n' +
              '4. Double-click topics to see insights, quotes, and entities\n' +
              '5. Use the analytics panel to explore relationships\n' +
              '6. Search for specific content using the search box\n' +
              '7. Generate AI insights for selected nodes or gaps\n' +
              '8. Hover over nodes to see detailed tooltips');
    });
    
    // Theme toggle (placeholder)
    document.getElementById('theme-toggle').addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
    });
});